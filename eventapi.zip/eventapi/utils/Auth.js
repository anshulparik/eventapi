const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const passport = require('passport');

// Register the user => (user, admin)
const userRegister = async (userDetails, role, res) => {
  try {
    // username validation
    const takenUsername = await validateUsername(userDetails.username);
    if (takenUsername == false) {
      return res.status(400).send("Username is already taken, TRY NEW!");
    }

    // password validation
    if(userDetails.password.length < 6){
      return res.status(400).send("Password should be atleast six characters long");
    }

    // hashing the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(userDetails.password, salt);

    // Adjusting the userDetails
    const newUser = await User({
      ...userDetails,
      role,
      password: hashedPassword,
    });

    await newUser.save();
    res.status(201).json(newUser);
  } catch (error) {
    res.status(500).json({ message: error });
  }
};

// Login the user => (user, admin)
const userLogin = async (userCredentials, role, res) => {
  const { username, password } = userCredentials;

  try {
    // Checking if username exists in DB
    const user = await User.findOne({ username });
    if (!user) {
      return res
        .status(404)
        .send("Username does not exists. Please register first");
    }

    // Checking for the correct role
    if (user.role !== role) {
      return res.status(400).send("Please login in from correct portal");
    }

    // Checking for the valid password
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(400).send("Invalid passowrd!");
    }

    let token = jwt.sign({ user_id: user._id }, process.env.TOKEN_SECRET);

    const signedUser = {
        name: user.name,
        username: user.username,
        role: user.role,
        token: `Bearer ${token}`
    }


    res.status(200).json({ ...signedUser });;

  } catch (error) {
    res.status(500).send({ message: error });
  }
};


// username validation
const validateUsername = async (username) => {
  const user = await User.findOne({ username });
  if (user) {
    return false;
  }

  return true;
};

/* --------------------------------------------------------------------------------------------------- */


// auth middleware
const userAuth = passport.authenticate('jwt', { session: false });

// Hiding password from user object
const serializeUser = (user) => {
    return  {
        _id: user. _id,
        name: user.name,
        username: user.username,
        role: user.role,
        wallet: user.wallet
    }
}

// Check role middleware
const checkRole = (roles) => (req, res, next) => {
  try {
    if(roles.includes(req.user.role)){
        return next();
    }

    res.status(401).send('Unauthorized Portal');
  } catch (error) {
        res.status(500).json({ message: error });
  }
}

module.exports = {
  userRegister,
  userLogin,
  userAuth,
  serializeUser,
  checkRole
};
