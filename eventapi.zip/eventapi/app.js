const express = require('express');
const mongoose = require('mongoose');
const routes = require('./routes/routes');
const dotenv = require('dotenv');
const passport = require('passport');

dotenv.config();

const app = express();
const port = 3000;

app.use(passport.initialize());
require('./middlewares/passport')(passport);

app.use(express.json());
app.use('/', routes);

// RUN mongod.exe with dbpath folder for connnection
// Example---->> /f/Work/Database/mongodb/bin/mongod.exe --dbpath=/f/Work/Database/eventhandle-data 

// DB connection
mongoose.connect('mongodb://localhost:27017/eventapi')
.then(() =>{
    console.log('DB connected successfully');
}).catch((err) =>{
    console.log(`Some error occured -->> ${err}`);
});


app.listen(port, () => {
    console.log(`App is listening on port ${port}`);
});