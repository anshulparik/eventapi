const express = require("express");
const User = require("../models/User");
const Event = require("../models/Event");
const {
  userRegister,
  userLogin,
  userAuth,
  serializeUser,
  checkRole,
} = require("../utils/Auth");
const router = express.Router();

//  Authenticated user(logged in) --->> req.user


// User registration
router.post("/reg-user", async (req, res) => {
  await userRegister(req.body, "user", res);
});

// Admin registration
router.post("/reg-admin", async (req, res) => {
  await userRegister(req.body, "admin", res);
});

// User login
router.post("/log-user", async (req, res) => {
  await userLogin(req.body, "user", res);
});

// Admin login
router.post("/log-admin", async (req, res) => {
  await userLogin(req.body, "admin", res);
});


// Cretaing Event
router.post("/event", userAuth, checkRole(["admin"]), async (req, res) => {
  const event = new Event({
    name: req.body.name,
    status: req.body.status,
    price: req.body.price,
    startDate: req.body.startDate,
    endDate: req.body.endDate,
  });

  try {
    const savedEvent = await event.save();
    res.status(201).json(savedEvent);
  } catch (error) {
    res.status(500).json({ message: error });
  }
});

// Deleting Event
router.delete(
  "/event/:id",
  userAuth,
  checkRole(["admin"]),
  async (req, res) => {
    try {
      const removedEvent = await Event.remove({ _id: req.params.id });
      res.json(removedEvent);
    } catch (error) {
      res.status(500).json({ message: error });
    }
  }
);

// Updating Event
router.patch("/event/:id", userAuth, checkRole(["admin"]), async (req, res) => {
    const _id = req.params.id;

    const updates = Object.keys(req.body); 
    const allowedUpdates = ['name', 'status', 'price', 'startDate', 'endDate'];
    const isValidOperation = updates.every((update)=>{
        return allowedUpdates.includes(update);
    })

    if (!isValidOperation) {
        return res.status(400).send({Error: 'Invalid Updates!'});
    }

    try {
         
        const event = await Event.findByIdAndUpdate(_id, req.body, {new: true, runValidators: true});

        if (!event) {
            return res.status(404).send();
        }
        
        updates.forEach((update)=>{
            event[update] = req.body[update];
        })
        
        await event.save();
        res.json(event);
    } catch (error) {
       res.status(400).json({ message: error }); 
    }
     

});

// User joining particular event(id)
router.post(
  "/join-event/:id",
  userAuth,
  checkRole(["user"]),
  async (req, res) => {
    try {
      const foundEvent = await Event.findByIdAndUpdate(
        { _id: req.params.id },
        { $push: { users: req.user } }
      );
        // Wallet validation
      if (req.user.wallet >= foundEvent.price) {
        req.user.wallet = req.user.wallet - foundEvent.price;
        await req.user.save();
        const savedEvent = await foundEvent.save();
        res.status(200).json({ message: "Event joined", savedEvent });
      } else {
        return res.status(400).send("Insufficient amount inside the wallet");
      }
    } catch (error) {
      res.status(500).json({ message: error });
    } 
  }
);

// Getting the list of participants(event id)
router.get("/:id", userAuth, checkRole(["user"]), async (req, res) => {

  try {
    const foundEvent = await Event.findById({ _id: req.params.id });

    const participants = await User.find({ _id : { $in : foundEvent.users }});
    // console.log(participants);
    res.status(200).json(participants);
  } catch (error) {
    res.status(500).json({ message: error});
  }
    

});
 
module.exports = router;
